#ifndef DEPARTMENT_H
#define DEPARTMENT_H

enum class Department {
    DEVELOPMENT,
    TESTING,
    INTEGERATION
};

#endif // DEPARTMENT_H
